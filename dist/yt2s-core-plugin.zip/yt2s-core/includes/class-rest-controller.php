<?php
if (!defined('ABSPATH')) {
    exit;
}

final class YT2S_Rest_Controller {
    private YT2S_Core $plugin;

    public function __construct(YT2S_Core $plugin) {
        $this->plugin = $plugin;
    }

    public function register_routes(): void {
        register_rest_route('yt2s/v1', '/ping', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [$this, 'handle_ping'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route('yt2s/v1', '/fetch', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [$this, 'handle_fetch'],
            'permission_callback' => [$this, 'permission_callback'],
            'args' => [
                'source_url' => [
                    'required' => true,
                    'type' => 'string',
                ],
                'job_id' => [
                    'required' => false,
                    'type' => 'string',
                ],
                'format_id' => [
                    'required' => false,
                    'type' => 'string',
                ],
            ],
        ]);

        register_rest_route('yt2s/v1', '/status/(?P<job_id>[A-Za-z0-9_-]+)', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [$this, 'handle_status'],
            'permission_callback' => [$this, 'permission_callback'],
        ]);
    }

    public function handle_ping(): WP_REST_Response {
        return new WP_REST_Response([
            'ok' => true,
            'service' => 'yt2s-core',
            'version' => YT2S_CORE_VERSION,
        ], 200);
    }

    public function permission_callback(WP_REST_Request $request): bool|WP_Error {
        $nonce = $request->get_header('x-yt2s-nonce');

        if (!$this->plugin->verify_nonce($nonce)) {
            return new WP_Error('yt2s_core_forbidden', 'Invalid request token.', ['status' => 403]);
        }

        return true;
    }

    public function handle_fetch(WP_REST_Request $request): WP_REST_Response|WP_Error {
        $payload = [
            'source_url' => esc_url_raw((string) $request->get_param('source_url')),
            'job_id' => sanitize_text_field((string) $request->get_param('job_id')),
            'format_id' => sanitize_text_field((string) $request->get_param('format_id')),
        ];

        if ('' === $payload['source_url'] || !wp_http_validate_url($payload['source_url'])) {
            return new WP_Error('yt2s_core_invalid_url', 'Please provide a valid URL.', ['status' => 400]);
        }

        $engine_response = $this->forward_to_engine('/media/fetch', $payload, 'POST');

        if (is_wp_error($engine_response)) {
            return $engine_response;
        }

        return new WP_REST_Response($engine_response, 200);
    }

    public function handle_status(WP_REST_Request $request): WP_REST_Response|WP_Error {
        $job_id = sanitize_text_field((string) $request->get_param('job_id'));

        if ('' === $job_id) {
            return new WP_Error('yt2s_core_missing_job', 'Missing job id.', ['status' => 400]);
        }

        $engine_response = $this->forward_to_engine('/media/jobs/' . rawurlencode($job_id), [], 'GET');

        if (is_wp_error($engine_response)) {
            return $engine_response;
        }

        return new WP_REST_Response($engine_response, 200);
    }

    private function forward_to_engine(string $path, array $payload, string $method): array|WP_Error {
        $url = $this->plugin->get_engine_url() . $path;
        $headers = [
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
        ];

        $api_key = $this->plugin->get_api_key();

        if ('' !== $api_key) {
            $headers['X-Yt2s-Api-Key'] = $api_key;
        }

        $args = [
            'method' => $method,
            'timeout' => 30,
            'headers' => $headers,
        ];

        if ('GET' !== $method) {
            $args['body'] = wp_json_encode($payload);
        }

        $response = wp_remote_request($url, $args);

        if (is_wp_error($response)) {
            return new WP_Error('yt2s_core_engine_error', $response->get_error_message(), ['status' => 502]);
        }

        $status_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        $decoded = json_decode($body, true);

        if (!is_array($decoded)) {
            return new WP_Error('yt2s_core_bad_response', 'The engine returned an invalid response.', ['status' => 502]);
        }

        if ($status_code >= 400) {
            $message = isset($decoded['detail']) && is_string($decoded['detail']) ? $decoded['detail'] : 'The engine rejected the request.';
            return new WP_Error('yt2s_core_engine_rejected', $message, ['status' => $status_code]);
        }

        return $decoded;
    }
}
